﻿namespace Calc
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbWynik = new System.Windows.Forms.TextBox();
            this.b7 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.bDod = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.bOdej = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.bMnoz = new System.Windows.Forms.Button();
            this.b0 = new System.Windows.Forms.Button();
            this.bWynik = new System.Windows.Forms.Button();
            this.bDziel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbWynik
            // 
            this.tbWynik.Location = new System.Drawing.Point(12, 12);
            this.tbWynik.Name = "tbWynik";
            this.tbWynik.Size = new System.Drawing.Size(138, 20);
            this.tbWynik.TabIndex = 0;
            // 
            // b7
            // 
            this.b7.Location = new System.Drawing.Point(12, 38);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(30, 23);
            this.b7.TabIndex = 1;
            this.b7.Text = "7";
            this.b7.UseVisualStyleBackColor = true;
            this.b7.Click += new System.EventHandler(this.b7_Click);
            // 
            // b8
            // 
            this.b8.Location = new System.Drawing.Point(48, 38);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(30, 23);
            this.b8.TabIndex = 2;
            this.b8.Text = "8";
            this.b8.UseVisualStyleBackColor = true;
            this.b8.Click += new System.EventHandler(this.b8_Click);
            // 
            // b9
            // 
            this.b9.Location = new System.Drawing.Point(84, 38);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(30, 23);
            this.b9.TabIndex = 3;
            this.b9.Text = "9";
            this.b9.UseVisualStyleBackColor = true;
            this.b9.Click += new System.EventHandler(this.b9_Click);
            // 
            // bDod
            // 
            this.bDod.Location = new System.Drawing.Point(120, 38);
            this.bDod.Name = "bDod";
            this.bDod.Size = new System.Drawing.Size(30, 23);
            this.bDod.TabIndex = 4;
            this.bDod.Text = "+";
            this.bDod.UseVisualStyleBackColor = true;
            this.bDod.Click += new System.EventHandler(this.bDod_Click);
            // 
            // b4
            // 
            this.b4.Location = new System.Drawing.Point(12, 67);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(30, 23);
            this.b4.TabIndex = 5;
            this.b4.Text = "4";
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.b4_Click);
            // 
            // b5
            // 
            this.b5.Location = new System.Drawing.Point(48, 67);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(30, 23);
            this.b5.TabIndex = 6;
            this.b5.Text = "5";
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.b5_Click);
            // 
            // b6
            // 
            this.b6.Location = new System.Drawing.Point(84, 67);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(30, 23);
            this.b6.TabIndex = 7;
            this.b6.Text = "6";
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.b6_Click);
            // 
            // bOdej
            // 
            this.bOdej.Location = new System.Drawing.Point(120, 67);
            this.bOdej.Name = "bOdej";
            this.bOdej.Size = new System.Drawing.Size(30, 23);
            this.bOdej.TabIndex = 8;
            this.bOdej.Text = "-";
            this.bOdej.UseVisualStyleBackColor = true;
            this.bOdej.Click += new System.EventHandler(this.bOdej_Click);
            // 
            // b1
            // 
            this.b1.Location = new System.Drawing.Point(12, 96);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(30, 23);
            this.b1.TabIndex = 9;
            this.b1.Text = "1";
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.b1_Click);
            // 
            // b2
            // 
            this.b2.Location = new System.Drawing.Point(48, 96);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(30, 23);
            this.b2.TabIndex = 10;
            this.b2.Text = "2";
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.b2_Click);
            // 
            // b3
            // 
            this.b3.Location = new System.Drawing.Point(84, 96);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(30, 23);
            this.b3.TabIndex = 11;
            this.b3.Text = "3";
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.b3_Click);
            // 
            // bMnoz
            // 
            this.bMnoz.Location = new System.Drawing.Point(120, 96);
            this.bMnoz.Name = "bMnoz";
            this.bMnoz.Size = new System.Drawing.Size(30, 23);
            this.bMnoz.TabIndex = 12;
            this.bMnoz.Text = "*";
            this.bMnoz.UseVisualStyleBackColor = true;
            this.bMnoz.Click += new System.EventHandler(this.bMnoz_Click);
            // 
            // b0
            // 
            this.b0.Location = new System.Drawing.Point(12, 125);
            this.b0.Name = "b0";
            this.b0.Size = new System.Drawing.Size(30, 23);
            this.b0.TabIndex = 13;
            this.b0.Text = "0";
            this.b0.UseVisualStyleBackColor = true;
            this.b0.Click += new System.EventHandler(this.b0_Click);
            // 
            // bWynik
            // 
            this.bWynik.Location = new System.Drawing.Point(48, 125);
            this.bWynik.Name = "bWynik";
            this.bWynik.Size = new System.Drawing.Size(66, 23);
            this.bWynik.TabIndex = 14;
            this.bWynik.Text = "=";
            this.bWynik.UseVisualStyleBackColor = true;
            this.bWynik.Click += new System.EventHandler(this.bWynik_Click);
            // 
            // bDziel
            // 
            this.bDziel.Location = new System.Drawing.Point(120, 125);
            this.bDziel.Name = "bDziel";
            this.bDziel.Size = new System.Drawing.Size(30, 23);
            this.bDziel.TabIndex = 15;
            this.bDziel.Text = "/";
            this.bDziel.UseVisualStyleBackColor = true;
            this.bDziel.Click += new System.EventHandler(this.bDziel_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(169, 176);
            this.Controls.Add(this.bDziel);
            this.Controls.Add(this.bWynik);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.bMnoz);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.bOdej);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.bDod);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.tbWynik);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Calc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbWynik;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button bDod;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button bOdej;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button bMnoz;
        private System.Windows.Forms.Button b0;
        private System.Windows.Forms.Button bWynik;
        private System.Windows.Forms.Button bDziel;
    }
}

